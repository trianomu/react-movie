import MovieList from '../components/MovieList'

export default function MovieDetail() {
  return (
    <div className="p-4 max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Movie Detail</h1>
      <MovieList />
    </div>
  )
}
