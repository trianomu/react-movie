import MovieList from '../components/MovieList'

export default function Home() {
  return (
    <div className="p-4 max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Popular Movies</h1>
      <h1 className="text-4xl font-bold text-center text-red-600 my-4">
        Tailwind Test Heading
        </h1>
      <MovieList />
    </div>
  )
}
