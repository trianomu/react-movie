import { useEffect, useState } from "react"
import type { Movie, MovieResponse } from "../types/movie"
import tmdb from "../api/apiHelper"
import MovieCard from "./MovieCard"
import SearchBar from "./Searchbar"

export default function() {
    const [movies, setMovies] = useState<Movie[]>([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState('')
    const [searchQuery, setSearchQuery] = useState('')
  
    const fetchMovies = async (query?: string) => {
        try {
          setLoading(true)
          const res = query
            ? await tmdb.get<MovieResponse>('/search/movie', { params: { query } })
            : await tmdb.get<MovieResponse>('/movie/popular')
          setMovies(res.data.results)
          setError('')
        } catch (err) {
          setError('Failed to fetch movies.')
        } finally {
          setLoading(false)
        }
    }
    
    const handleSearch = (query: string) => {
        setSearchQuery(query)
        fetchMovies(query)
    }
    
    useEffect(() => {
        fetchMovies()
    }, [])


    
    if (loading) return <p className="text-center">Loading...</p>
    if (error) return <p className="text-center text-red-500">{error}</p>
  
    return (
        <div>
            <SearchBar onSearch={handleSearch} />

            {loading && <p className="text-center">Loading...</p>}
            {error && <p className="text-red-500 text-center">{error}</p>}

            {!loading && movies.length === 0 && (
                <p className="text-center">No movies found.</p>
            )}
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {movies.map((movie) => (
                    <MovieCard key={movie.id} movie={movie} />
                ))}
            </div>
        </div>
    )
}