import { Link } from "react-router-dom";
import type { Movie } from "../types/movie";

interface Props{
    movie:Movie
}

export default function MovieCard({movie}:Props){
    return(
        <div className="bg-white shadow rounded p-2">
            <Link to={`/movie/${movie.id}`}>
                <img 
                    src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
                    alt={movie.title} />
            </Link>
            <h3 className="text-lg font-semibold mt-2">{movie.title}</h3>
            <p className="text-gray-500 text-sm">{new Date(movie.release_date).getFullYear()}</p>
        </div>
    )
}